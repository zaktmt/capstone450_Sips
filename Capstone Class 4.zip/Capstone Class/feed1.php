<!DOCTYPE html>
<!--social media feed-->

<html>

<!--Show feed-->
<head>
    <title>Sips Feed</title>
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/skeleton.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/feed.css">
</head>
<body>
    <h1>Sips</h1>
    <h2>Feed</h2>
    
    
    
    
    
    
    
    
</body>
</html>