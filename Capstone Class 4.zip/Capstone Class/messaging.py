from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

messages = []


@app.route('/')
def index():
    return render_template('index.html', messages=messages)


@app.route('/send_message', methods=['POST'])
def send_message():
    content = request.json.get('content')
    if content:
        messages.append({'content': content, 'sender': 'You'})
        # You can replace 'You' with the actual username or user ID
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'error': 'Content cannot be empty'})


if __name__ == '__main__':
    app.run(debug=True)
